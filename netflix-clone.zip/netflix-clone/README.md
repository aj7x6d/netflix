# netflix clone

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aj7x/pen/oNayLKQ](https://codepen.io/Aj7x/pen/oNayLKQ).

